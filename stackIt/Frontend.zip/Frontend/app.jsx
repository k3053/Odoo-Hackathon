import React, { useState, useEffect } from 'react';
import { Bell, Search, Plus, Heart, MessageCircle, Share2, Award, User, Settings, LogOut, Eye, ThumbsUp, ThumbsDown, Check, X, Menu, Home, Filter, ChevronLeft, ChevronRight } from 'lucide-react';

const StackItPlatform = () => {
  const [currentScreen, setCurrentScreen] = useState('home');
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    category: 'All',
    newest: true,
    unanswered: false,
    mostVoted: false
  });

  const questions = [
    {
      id: 1,
      title: 'How to join 2 columns in a data set to make a separate column in SQL',
      description: 'I am working on a SQL query and need to combine two columns into one. What is the best approach?',
      tags: ['SQL', 'Data'],
      author: 'User Name',
      votes: 5,
      answers: 2,
      views: 127,
      time: '2 hours ago'
    },
    {
      id: 2,
      title: 'Best practices for React state management',
      description: 'What are the recommended approaches for managing state in large React applications?',
      tags: ['React', 'State'],
      author: 'User Name',
      votes: 12,
      answers: 1,
      views: 89,
      time: '4 hours ago'
    },
    {
      id: 3,
      title: 'JavaScript async/await vs Promises',
      description: 'When should I use async/await versus traditional Promise chains?',
      tags: ['JavaScript', 'Async'],
      author: 'User Name',
      votes: 8,
      answers: 3,
      views: 203,
      time: '1 day ago'
    }
  ];

  const answers = [
    {
      id: 1,
      author: 'Alex Rodriguez',
      content: 'You can use the CONCAT function in SQL to combine two columns. For example: SELECT CONCAT(first_name, \' \', last_name) AS full_name FROM users;',
      votes: 8,
      time: '1 hour ago'
    },
    {
      id: 2,
      author: 'Sarah Chen',
      content: 'Another approach is to use the || operator (in PostgreSQL) or + operator (in SQL Server): SELECT first_name || \' \' || last_name AS full_name FROM users;',
      votes: 5,
      time: '30 minutes ago'
    }
  ];

  const AnimatedBackground = () => (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-purple-100 via-pink-50 to-orange-100 opacity-60"></div>
      <div className="absolute inset-0 bg-gradient-to-tr from-blue-100 via-green-50 to-yellow-100 opacity-40 animate-pulse" style={{ animationDelay: '2s' }}></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-purple-200 to-pink-300 rounded-full opacity-20 animate-bounce" style={{ animationDuration: '8s' }}></div>
      <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-gradient-to-r from-blue-200 to-green-300 rounded-full opacity-25 animate-bounce" style={{ animationDuration: '12s', animationDelay: '4s' }}></div>
    </div>
  );

  const MobileHeader = () => (
    <header className="bg-white/20 backdrop-blur-md border-b border-white/30 shadow-lg sticky top-0 z-50 md:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <button
          onClick={() => setShowMobileMenu(!showMobileMenu)}
          className="p-2 hover:bg-white/20 rounded-lg transition-all duration-200"
        >
          <Menu className="w-6 h-6 text-gray-700" />
        </button>
        <div className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          StackIt
        </div>
        <div className="flex items-center space-x-2">
          <Bell className="w-6 h-6 text-gray-700" />
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
      
      {showMobileMenu && (
        <div className="absolute top-full left-0 right-0 bg-white/95 backdrop-blur-md border-b border-white/30 shadow-lg">
          <div className="px-4 py-3">
            <div className="text-sm text-gray-600 mb-2">Filters</div>
            <div className="space-y-2">
              <select className="w-full px-3 py-2 bg-white/30 border border-white/40 rounded-lg text-sm">
                <option>All Questions</option>
                <option>Unanswered</option>
                <option>Most Voted</option>
              </select>
              <select className="w-full px-3 py-2 bg-white/30 border border-white/40 rounded-lg text-sm">
                <option>Newest</option>
                <option>Oldest</option>
                <option>Most Viewed</option>
              </select>
              <select className="w-full px-3 py-2 bg-white/30 border border-white/40 rounded-lg text-sm">
                <option>SQL</option>
                <option>JavaScript</option>
                <option>React</option>
                <option>Python</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </header>
  );

  const Sidebar = () => (
    <aside className="hidden md:flex flex-col w-64 bg-white/10 backdrop-blur-md border-r border-white/30 h-screen sticky top-0">
      <div className="p-4">
        <div className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-8">
          StackIt
        </div>
        <nav className="space-y-2">
          <button className="flex items-center space-x-2 w-full px-4 py-2 text-gray-700 hover:bg-white/20 rounded-lg transition-all duration-200">
            <Home className="w-5 h-5" />
            <span>Home</span>
          </button>
          <button className="flex items-center space-x-2 w-full px-4 py-2 text-gray-700 hover:bg-white/20 rounded-lg transition-all duration-200">
            <Award className="w-5 h-5" />
            <span>Top Questions</span>
          </button>
          <button className="flex items-center space-x-2 w-full px-4 py-2 text-gray-700 hover:bg-white/20 rounded-lg transition-all duration-200">
            <User className="w-5 h-5" />
            <span>Users</span>
          </button>
          <button className="flex items-center space-x-2 w-full px-4 py-2 text-gray-700 hover:bg-white/20 rounded-lg transition-all duration-200">
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </button>
        </nav>
      </div>
    </aside>
  );

  const QuestionList = () => (
    <div className="flex-1 p-4">
      <div className="flex flex-col space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-800">All Questions</h1>
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg flex items-center space-x-2 hover:opacity-90 transition-opacity">
            <Plus className="w-5 h-5" />
            <span>Ask Question</span>
          </button>
        </div>

        <div className="flex items-center space-x-4 overflow-x-auto pb-2">
          <div className="flex-1 relative">
            <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search questions..."
              className="w-full pl-10 pr-4 py-2 bg-white/30 border border-white/40 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <button className="p-2 hover:bg-white/20 rounded-lg transition-all duration-200">
            <Filter className="w-5 h-5 text-gray-700" />
          </button>
        </div>

        <div className="space-y-4">
          {questions.map(question => (
            <div key={question.id} className="bg-white/30 backdrop-blur-md border border-white/40 rounded-lg p-4 hover:bg-white/40 transition-all duration-200">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800 hover:text-purple-600 cursor-pointer">
                    {question.title}
                  </h3>
                  <p className="text-gray-600 mt-1">{question.description}</p>
                  <div className="flex items-center space-x-2 mt-2">
                    {question.tags.map(tag => (
                      <span key={tag} className="px-2 py-1 bg-white/20 rounded-full text-xs text-gray-600">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col items-end space-y-2 ml-4">
                  <div className="flex items-center space-x-1 text-gray-600">
                    <ThumbsUp className="w-4 h-4" />
                    <span>{question.votes}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-gray-600">
                    <MessageCircle className="w-4 h-4" />
                    <span>{question.answers}</span>
                  </div>
                  <div className="flex items-center space-x-1 text-gray-600">
                    <Eye className="w-4 h-4" />
                    <span>{question.views}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4 text-sm text-gray-500">
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span>{question.author}</span>
                </div>
                <span>{question.time}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center space-x-2 mt-4">
          <button className="p-2 hover:bg-white/20 rounded-lg transition-all duration-200">
            <ChevronLeft className="w-5 h-5 text-gray-700" />
          </button>
          <span className="text-gray-700">Page {currentPage}</span>
          <button className="p-2 hover:bg-white/20 rounded-lg transition-all duration-200">
            <ChevronRight className="w-5 h-5 text-gray-700" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <AnimatedBackground />
      <MobileHeader />
      <div className="flex">
        <Sidebar />
        <main className="flex-1">
          <QuestionList />
        </main>
      </div>
    </div>
  );
};

export default StackItPlatform;